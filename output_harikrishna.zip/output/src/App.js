import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./components/Home";
import UserList from "./components/UserList";
import AddUser from "./components/AddUser";
import EditUser from "./components/EditUser";
import "./App.css";

const App = () => {
  return (
    <Router>
      <nav>
        <Link to="/users">User List</Link> | 
        <Link to="/add-user">Add User</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        //<Route path="/users" element={<UserList />} />
       // <Route path="/add-user" element={<AddUser />} />
        <Route path="/edit-user/:id" element={<EditUser />} />
      </Routes>
    </Router>
  );
};

export default App;
